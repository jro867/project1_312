import random



def prime_test(N, k):
    # You will need to implements this function and change the return value.

    # To generate random values for a, you will most likley want to use
    # random.randint(low,hi) which gives a random integer between low and
    #  hi, inclusive.
	
	# Remember to ensure that all of your random values are unique
		
    # Should return one of three values: 'prime', 'composite', or 'carmichael'

	return 'prime'


def mod_exp(x, y, N):
    # You will need to implements this function and change the return value.
    
	return 1
	

def probability(k):
    # You will need to implements this function and change the return value.
    
    return 0.0


def is_carmichael(N,a):
    # You will need to implements this function and change the return value.

	return False

